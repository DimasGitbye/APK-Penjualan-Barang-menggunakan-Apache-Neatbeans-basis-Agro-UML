<?php $this->extend('shared_page/template'); ?>
<?php $this->section('content'); ?>
<div class="card-body">
    <a href="#" type="button" class="btn btn-success ml-2 my-4 tbl-menu"><i class="far fa-sticky-note mr-2"></i>Tampil Menu</a>
    <a href="#" type="button" class="btn btn-primary ml-2 my-4 btn-addmenu"><i class="fas fa-plus mr-2"></i>Tambah Menu</a>
    <div class="tampil"></div>
</div>
<?php $this->endSection(); ?>